/////////////////////////////////////////////////////////////////
//  Sets
/////////////////////////////////////////////////////////////////
// 1. add()
let mySet = new Set();
mySet.add("Apple");
mySet.add("Orange");
mySet.add("Apple");

// 2. size
console.log("\nSize of the set = "  + mySet.size);
console.log("Contents of the set are ")

// 3a. values()
for (let element of mySet.values()) {
  console.log(element);
}

// 3b. entries()
for (let [key, value] of mySet.entries()) {
  console.log(key + '=' + value);
}

// 4. has()
console.log("\nSet has the value Apple -> "  + mySet.has("Apple"));
console.log("Set has the value Mango -> "  + mySet.has("Mango"));

// 5. delete()
// mySet.delete("Apple");
// console.log("\nSet has the value Apple -> "  + mySet.has("Apple"));

// 6. clear()
// mySet.clear();
// console.log("\nSize of the set = "  + mySet.size);

// 7. Converting a set into an array
let newArray = [...mySet];
console.log("\nSize of newArray = " +  newArray.length);
console.log("Contents of newArray = " +  newArray);

// 8. Set can be constructed by passing array as an argument
let aSet = new Set(["Tennis", "Cricket", "Soccer"]);
console.log("\nSize of aSet = "  + aSet.size);

// 9. a) Converting an array into set
//     b) Eliminating duplicates
let myArray = [1, 2, 2, 2, 3, 4];
console.log("\n=> Size of myArray = " +  myArray.length);
console.log("Contents of myArray = " +  myArray);
let newSet = new Set(myArray);
console.log("=> Size of newSet = "  + newSet.size);
let uniqueArray = [...newSet];
console.log("=> Size of uniqueArray = " +  uniqueArray.length);
console.log("Contents of uniqueArray = " +  uniqueArray);
