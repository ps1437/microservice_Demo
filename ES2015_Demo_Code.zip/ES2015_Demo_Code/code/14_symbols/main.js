// 1. Each time Symbol function is called, a new unique value is generated.
let symbolOne = Symbol();
let symbolTwo = Symbol();
console.log("1. Every symbol is unique");
console.log(symbolOne === symbolTwo);
//==============================================================================
// 2. Symbol function accepts an optional parameter, which is just a name used for debugging purposes
//    and it will not affect in any way the unique value generated.
let hello = Symbol('hello');
let world = Symbol('world');
console.log("2. An optional parameter can be passed to Symbol function to provide a name");
console.log(hello === world);
console.log('Variable hello is assigned ' + hello.toString());
//==============================================================================
// 3. Symbols are primitive types just like string, number, boolean etc.
console.log("3. Symbols are of primitive type called symbol");
console.log(typeof hello);
//==============================================================================
// 4. Global Registry
// Symbol.for(..) retrieves the symbol for a given key from the global registry, if it exists.
// Otherwise, a new symbol is returned and subsequent Symbol.for will return it.
let sunday = Symbol.for('week');
let monday = Symbol.for('week');
console.log("3. Demo of Symbol.for");
console.log(sunday === monday);
//==============================================================================
// 5. Using Symbol.keyFor, the key for a given symbol can be retrieved.
console.log("4. Demo of Symbol.keyFor");
console.log(Symbol.keyFor(sunday));
//==============================================================================
// 6. Symbols can be used as unique property keys.
let firstMonth = Symbol("first month");
let monthList = { };
monthList[firstMonth] = "January";
console.log(monthList[firstMonth]);
// Making the property read only
Object.defineProperty(monthList, firstMonth, { writable: false });
monthList[firstMonth] = "May";
console.log(monthList[firstMonth]);
//==============================================================================
// 7. Symbols can be used to reprsent constants.
console.log("7a. Demo of constants using Symbols");
const SEASON_SPRING = Symbol("Spring");
const SEASON_SUMMER = Symbol("Summer");
const FRAMEWORK_SPRING = Symbol("Frameowork Spring");

function getSeasonName(season) {
  switch (season) {
    case SEASON_SPRING:
      console.log("Spring season");
      break;
    case SEASON_SUMMER:
      console.log("Summer season");
      break;
    default:
      console.log('Unknown season: ' + season.toString());
  }
}
getSeasonName(SEASON_SPRING);
getSeasonName(FRAMEWORK_SPRING);

console.log("7b. Demo of constants using String constants");
const SEASON1_SPRING = "Spring";
const SEASON1_SUMMER = "Summer";
const FRAMEWORK1_SPRING = "Spring";

function getSeason1Name(season) {
  switch (season) {
    case SEASON1_SPRING:
      console.log("Spring season");
      break;
    case SEASON1_SUMMER:
      console.log("Summer season");
      break;
    default:
      console.log('Unknown season: ' + season.toString());
  }
}
getSeason1Name(SEASON1_SPRING);
getSeason1Name(FRAMEWORK1_SPRING);
//==============================================================================
