// 1. Simple example - using variables
console.log("\n1) Simple destructuring - using variables")
let a = 6;
let b = 9;
console.log("Before Destructuring => a=%d, b=%d", a, b);
[a, b] = [b, a];
console.log("After Destructuring => a=%d, b=%d", a, b);
//==============================================================================
// 2. Simple example - function returning an array
console.log("\n2) Simple destructuring - function returning an array")
function getNumList() {
  return [1, 2, 3];
}
let [x, y , z] = getNumList();
console.log("Destructuring the returned array => Values of x, y, z = %d, %d, %d", x, y , z);
let [m, , n] = getNumList();
console.log("Destructuring the returned array (skipping some elements)=> Values of m, n = %d, %d", m, n);

//==============================================================================
// ES5 way
console.log("\n3) With objects");

var objectCar = {
  model: "Honda",
  color: "red"
}
var model1 = objectCar.model;
var color1 = objectCar.color;
console.log("ES5 way => %s, %s", model1, color1);

// 3. ES2015 - Destructuring way
var {model, color:carColor} = {
  model: "BMW",
  color: "blue"
}
console.log("ES2015 Destructuring way => %s, %s", model, carColor);
//==============================================================================
// 4a. Can be used to retrieve values from an object returned by a function
console.log("\n4) Destructuring with an object returned by a function");

function getCarInfo() {
  return {
    model: "Audi",
    color: "black"
  }
}
var {model} = getCarInfo();
console.log("\nRetrieve value from object returned by function => %s", model);

//4b.
function getAnotherCarInfo() {
  return {
    model: "Vitara",
    color: "red"
  }
}
var {color: myColor} = getAnotherCarInfo();
console.log("Retrieve value from object returned by function (assign to a different variable name) => %s", myColor);

//==============================================================================
// 5. Can be used to retrieve values from an array
console.log("\n5) With arrays");
var [season1,,season3] = ["Summer", "Spring", "Autumn", "Winter"];
console.log("Destructuring in Arrays => %s, %s", season1, season3);
//==============================================================================
// 6. Can iterate an array of objects and retrieve the specific key
console.log("\n6) Destructuring in Array Iteration...");
var cars = [
  {
    model: "Honda",
    color: "red"
  },
  {
    model: "BMW",
    color: "blue",
  },
  {
    model: "Audi",
    color: "black"
  }
]
cars.forEach(({model,color}) => console.log(model + " " + color));
//==============================================================================
// 7. Destructuring complex object
console.log("\n7) Destructuring a complex object");
function getEmployeeDetails() {
  return {
    name: "Ram",
    location: "Chennai",
    contacts: {
      email: "ram@mail.com",
      mobile: "9766612345"
    }
  };
}
var {
    name,
    contacts:{mobile}
} = getEmployeeDetails();
console.log("Name = " + name);
console.log("Mobile = " + mobile);
