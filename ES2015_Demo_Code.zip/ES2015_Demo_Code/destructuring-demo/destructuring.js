

// 1. Simple example - using variables

let xa=15 , xb =20;

console.log("Before Destructuring => xa=%d, xb=%d", xa, xb);
[xa, xb] = [xb, xa];
console.log("After Destructuring => xa=%d, xb=%d", xa, xb);


//==============================================================================
// 2. Simple example - function returning an array
console.log("\n2) Simple destructuring - function returning an array")

function getMulList(value){
	
	return [1*value , 2*value];
}


let [x, y] = getMulList(4);
console.log("Destructuring the returned array => Values of x = %d, y=%d", x, y );
let [ , n] = getMulList(4);
console.log("Destructuring the returned array (skipping some elements)=> Values of y= %d",n);

//==============================================================================
// ES5 way
console.log("\n3) With objects");

var user = {
name:"Praveen",
	age :25,
	gender :"M"
}
var name = user.name;
var age = user.age;
console.log("ES5 way => %s, %s", name, age);


var {name ,age}= {
	
	name:"Praveen",
	age :25,
	gender :"M"
	
}

console.log("ES2015 Destructuring way => %s, %s", name, age);
//==============================================================================
// 4a. Can be used to retrieve values from an object returned by a function
console.log("\n4) Destructuring with an object returned by a function");

function getUserInfo() {
  return {
   name:"Praveen",
	age :25,
	gender :"M"
  }
}
var {name} = getUserInfo();
console.log("\nRetrieve value from object returned by function => %s", name);

//4b.
function getAnotherUserInfo() {
  return {
    name:"Praveen",
	age :25,
	gender :"M"
  }
}
var {gender: gender} = getAnotherUserInfo();
console.log("Retrieve value from object returned by function (assign to a different variable name) => %s", gender);

//==============================================================================
// 5. Can be used to retrieve values from an array
console.log("\n5) With arrays");
var [season1,,season3,season4] = ["Summer", "Spring", "Autumn", "Winter"];
console.log("Destructuring in Arrays => %s, %s ,%s", season1, season3 ,season4);
//==============================================================================
// 6. Can iterate an array of objects and retrieve the specific key
console.log("\n6) Destructuring in Array Iteration...");
var users = [
  {
    name: "RK",
    age:  25
  },
  {
    name:  "MK",
    age: 21,
  },
  {
    name: "LK",
    age:  12
  }
]
users.forEach(({name,age}) => console.log(name + " " + age));
//==============================================================================
// 7. Destructuring complex object
console.log("\n7) Destructuring a complex object");
function getEmployeeDetails() {
  return {
    name: "RK",
    location: "Hyderabad",
	gender : "M",
    contacts: {
      email: "rk@mgail.com",
      mobile: "1231451"
    },
	address :{
		street : " 21 BA street",
		area  :" Charminar ",
		code :"51200"
	}
  };
}
var {
    name,
    contacts:{mobile},
	address:{street,area}
} = getEmployeeDetails();
console.log("Name = " + name);
console.log("Mobile = " + mobile);
console.log("Street = " + street);