// 1. var - hoisting
function compute(option) {
  if (option === 0) {
    var score = 100;
    return score;
  } else if (option === 1){
    return score;
  }
  return score;
}
console.log("==> 1) var - hoisting");
console.log(compute(0));
console.log(compute(1));
console.log(compute(2));
//------------------------------------------------------------------------------
// => UNCOMMENT the below function to analyze the let behavior
// => Please note you will get error which is normal
/*
function compute_let(option) {
  if (option === 0) {
    let score = 100;
    return score;
  } else if (option === 1){
    return score;
  }
  return score;
}
console.log(compute_let(0));
console.log(compute_let(1));
console.log(compute_let(2));
*/
//==============================================================================
// 2. Using var - ES5 [ Scoping problems]
console.log("\n==> 2) var - scoping problems");
var number1 = 10;
if (true) {
  var number1 = 20;
  console.log("(Using var) In if block => number1 = %d", number1);
}
console.log("(Using var) Outside if block => number1 = %d", number1);
//------------------------------------------------------------------------------
// 3. Using let - ES2015 [ let is block scoped ]
console.log("\n==> 3) let - block scoped");
let number2 = 10;
if (true) {
  let number2 = 20;
  console.log("(Using let) In if block => number2 = %d", number2);
}
console.log("(Using let) Outside if block => number2 = %d\n", number2);
//==============================================================================
// 4. var in for loop - ES5
console.log("\n==> 4) var - for loop");
for (var m = 0; m < 10; m++) {
}
// With var, m can be accessed here
console.log(m);
//------------------------------------------------------------------------------
// let in for loop - ES2015
// => UNCOMMENT the below code to analyze the let behavior in for loop
// => Please note you will get error which is normal
/*
for (let n = 0; n < 10; n++) {
}
// With let, n cannot be accessed here
console.log(n);
*/
//==============================================================================
// 5. var - functions in loop - ES5
console.log("\n==> 5) var - functions in loop");
for(var i = 0; i < 5; i++) {
  setTimeout(function() {
    console.log("i = %d", i);
  }, 1000);
}
//------------------------------------------------------------------------------
// 6. let - functions in loop - ES2015
console.log("\n==> 6) let - for loop");
for(let j = 0; j < 5; j++) {
  setTimeout(function() {
    console.log("j = %d", j);
  }, 1000);
}
//==============================================================================
