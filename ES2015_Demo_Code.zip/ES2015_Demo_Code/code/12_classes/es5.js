function Person(name, age) {
  this.name = name;
  this.age = age;
}

Person.prototype.speak = function() {
  return this.name + " speaking...";
}

const person1 = new Person("Vinay", 27);
console.log(person1.speak());

function Athelete(sportsCategory) {
  this.sportsCategory = sportsCategory;
}

Athelete.prototype = new Person("Rahul", 25);

Athelete.prototype.run = function() {
  return this.name + " running in " + this.sportsCategory;
}

const athelete1 = new Athelete("100m");
console.log(athelete1.run());

console.log(athelete1.speak());
