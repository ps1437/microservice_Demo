// 1. Simple generator



function* generateNumbers() {
  console.log("\nGoing to generate numbers...");
  yield 10;
  yield 15;
}

let numbers = generateNumbers();
console.log(numbers.next());
console.log(numbers.next());
console.log(numbers.next());
console.log(numbers.next());

// 2. Using for loop
let numbers2 = generateNumbers();
for (let number of numbers2) {
  console.log(number);
}

// 3. Passing value to next
function* generateNumberPattern(start, count) {
  let numCount = 0;
  console.log("\nGoing to generate number pattern...");
  let currentNumber = start;
  while (numCount < count) {
    let increment = yield currentNumber;
    currentNumber += increment || 2;
    numCount--;
  }
}

let numberPattern = generateNumberPattern(10, 20);
console.log(numberPattern.next());
console.log(numberPattern.next(2));
console.log(numberPattern.next(5));
