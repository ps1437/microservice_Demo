// 1. Tagged templates
const tagFunction = (strings, name, marksObtained) => {

  let str0 = strings[0]; // "Student "
  let str1 = strings[1]; // " has "
  let str2 = strings[2]; // " in Maths"

  let strResult = (marksObtained >= 40) ? 'passed' : 'failed';

  return str0 + name + str1 + strResult + str2;
}

let name = 'Ram';
let marks = 85;
let strOutput = tagFunction`Student ${ name } has ${ marks } in Maths`;
console.log(strOutput);

name = 'Raj';
marks = 36;
strOutput = tagFunction`Student ${ name } has ${ marks } in Maths`;
console.log(strOutput);
