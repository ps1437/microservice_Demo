// 1. SINGLE ARGUMENT
// ES5 - Normal function
var sayHello = (name)=>"Hi " +name;

console.log(sayHello("Praveen"));

// 2. MULTIPLE ARGUMENTS
// ES5 - Normal function


var  subNum = (a,b)=>a-b;;

console.log("sub of  20 - 10 = " + subNum(20,10));

// 3. NO ARGUMENTS
var sayHi = () => "Hi User";

console.log(sayHi());
//==============================================================================
// 5. FUNCTION THAT DOES NOTHING

var emptyFun = () => {};
//==============================================================================
// 6. RETURNING AN OBJECT LITERAL
// ES5 - Normal function

var empInfo = () =>({id:1,
name: "Soni"});

console.log("Employee Info :  "+ JSON.stringify(empInfo()));

	  
	 
var empInfo = (id,name) =>({id:id,
name: name});

console.log("Employee Info :  "+ JSON.stringify(empInfo(2,"Praveen")));
 
	  
//==============================================================================
// arrow function - ES2015
var User = {
  message: "Hello",
  handleDisplay: function(displayType, handler) {
    handler(displayType);
  },
  showData: function() {
    this.handleDisplay(true,
      displayType => console.log(displayType ? this.message.toUpperCase() : this.message.toLowerCase())) 
  }
  
  
}
User.showData();
//==============================================================================
