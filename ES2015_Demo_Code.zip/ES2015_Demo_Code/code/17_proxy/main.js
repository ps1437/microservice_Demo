var car = {
  model: 'Honda',
  color: 'red',
  numWheels: 4
}

// 1. Proxy intercepting get operations on property
console.log("1) Getting properties of Car object");
var proxyCar1 = new Proxy(car, {
  get: function(target, property) {
    if (property === 'model') {
      return target[property].toUpperCase();
    }
    else {
      return target[property];
    }
  }
});
console.log(`Car => Model: ${proxyCar1.model}, Color: ${proxyCar1.color}, Wheels: ${proxyCar1.numWheels}`);

// 2. Proxy intercepting set operations on property
console.log("\n2) Setting properties of Car object");
var proxyCar2 = new Proxy(car, {
  set: function(target, property, value) {
    if (property === 'numWheels' && value != 4) {
      console.log('==> Car can have only 4 wheels');
    }
    else {
      target[property] = value;
    }
  }
});
proxyCar2.color = 'blue';
proxyCar2.numWheels = 6;

console.log(`Car => Model: ${proxyCar2.model}, Color: ${proxyCar2.color}, Wheels: ${proxyCar2.numWheels}`);
