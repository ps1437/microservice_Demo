// 1. ES5 way - Property initializer and method definition
var model = "Honda";
var color = "red";

var car1 = {
  model: model,
  color: color,
  drive: function() {
    console.log("car1 drive...");
  }
};
console.log("\n1) Using ES5 ==> Model = %s, Color = %s", car1.model, car1.color);
car1.drive();

// ES2015 way - Property initializer and method definition
let car2 = {
	model,
	color,
	drive() {
		console.log("car2 drive...");
	}
}
console.log("\n2) Using ES2015 ==> Model = %s, Color = %s", car2.model, car2.color);
car2.drive();
//==============================================================================
// 2. ES5 - Computed Properties
function generateObjectES5(propertyName, propertyValue) {
	var object = {};
	object[propertyName] = propertyValue;
	return object;
}
var carObject1 = generateObjectES5('model', 'BMW');
console.log("\n3) Using ES5 ==> Car1 Model = %s", carObject1.model);

// ES2015 - Computed Properties
function generateObjectES2015(propertyName, propertyValue) {
	return {
		[propertyName]: propertyValue
	}
}
let carObject2 = generateObjectES2015('model', 'Audi');
console.log("\n4) Using ES2015 ==> Car2 Model = %s", carObject2.model);
//==============================================================================
// 3. ES2015 - Computed Properties with String concatenation
function createUsers(user1, user2) {
	return {
		['user_' + user1.id]:user1,
		['user_' + user2.id]:user2
	}
}
let Ram = {id:1, name: 'Ram'};
let Vinay = {id:2, name: 'Vinay'};

let users = createUsers(Ram, Vinay);
console.log("\n5) String concat => users = " + JSON.stringify(users));
//==============================================================================
