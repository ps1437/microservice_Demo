package com.syscho.microservices.currencyconversionservice;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class CurrencyConsumeController {

	@Autowired
	private CurrencyExchangeServiceProxy proxy;

	@GetMapping("/currency-exchange/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversionBean convertCurrency(@PathVariable("from") String fromCurrency,
			@PathVariable("to") String toCurrency, @PathVariable("quantity") BigDecimal quantity) {

		ResponseEntity<CurrencyConversionBean> objEntity = new RestTemplate().getForEntity(
				"http://localhost:8100/currency-exchange/from/{from}/to/{to}", CurrencyConversionBean.class,
				new Object[] { fromCurrency, toCurrency });
		CurrencyConversionBean body = objEntity.getBody();
		body.setQuantity(quantity);
		body.setTotalCalculatedAmount(body.getQuantity().multiply(body.getConversionMultiple()));

		return body;
	}

	@GetMapping("/currency-exchange-geign/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversionBean convertCurrencyFeign(@PathVariable("from") String fromCurrency,
			@PathVariable("to") String toCurrency, @PathVariable("quantity") BigDecimal quantity) {

		CurrencyConversionBean retrieveExchangeValue = proxy.retrieveExchangeValue(fromCurrency, toCurrency);
		retrieveExchangeValue
				.setTotalCalculatedAmount(quantity.multiply(retrieveExchangeValue.getConversionMultiple()));
		return retrieveExchangeValue;
	}

}
