/////////////////////////////////////////////////////////////////
//  Maps
/////////////////////////////////////////////////////////////////
let myMap = new Map();
let userObj = {};
let aFunc = function() {};

// Map methods
// 1. set()
myMap.set("name", "Ram");
myMap.set("id", 100);
myMap.set(userObj, {"name": "Raj", "location": "Pune"});
myMap.set(aFunc, "Key is a function");

// 2. get()
console.log("Name = %s", myMap.get("name"));
console.log("ID = %d", myMap.get("id"));
console.log("User Object = " +  JSON.stringify(myMap.get(userObj)));
console.log("Value stored in function key = " + myMap.get(aFunc));

// 3. has()
console.log("\nMap has the name key -> "  + myMap.has("name"));
console.log("Map has the location key -> "  + myMap.has("location"));

// 4. size
console.log("\nSize of the map = %d", myMap.size);

// 5. clear()
//myMap.clear();
//console.log("Size of the map = %d", myMap.size);

// Map Iterators
// 6. keys()
console.log("\nKeys present in the map are ");
for (let key of myMap.keys()) {
  console.log(key);
}

// 7. values()
console.log("\nValues present in the map are ");
for (let value of myMap.values()) {
  console.log(value);
}

// 8. entries()
console.log("\nValues present in the map are ");
for (let [key, value] of myMap.entries()) {
  console.log(key + '=' +  value);
}
