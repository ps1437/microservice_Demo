// 1. Normal Array
let normalArray = [1025, 2050, 4099, 8196]; // 256 bits in unoptimized
console.log(normalArray);
//==============================================================================
// 2. Typed Array
let arrBuffer = new ArrayBuffer(16); // 128 bits
let view1 = new Int32Array(arrBuffer); // 4 integers
console.log(view1);
view1[0] = 1025;
view1[1] = 2050;
view1[2] = 4099;
view1[3] = 8196;
view1[4] = 16384;   // This will NOT get set.

console.log(view1);
let view2 = new Int8Array(arrBuffer); // 16 integers
console.log(view2);
//==============================================================================
// 3. Tyoed Array to Buffer
const typedArray = new Int32Array([60, 70, 80]);
console.log(typedArray.length);
typedArray[1] = 90;
const arrayView = new DataView(typedArray.buffer);
console.log(arrayView);
console.log(arrayView.getInt32(1));
//==============================================================================
