package com.syscho.microservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.syscho.microservices.beans.LimitBean;

@RestController
public class LimitController {

	@Autowired
	private ConfigProperty config;

	@GetMapping("/limits")
	public LimitBean getLimits() {

		return new LimitBean(config.getMinimum(), config.getMaximum());
	}

}
