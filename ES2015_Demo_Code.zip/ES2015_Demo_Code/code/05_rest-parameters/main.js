// 1. ES5 - Using arguments object
function add(str) {
  var sum = 0;
  var len = arguments.length;
  for (var i=0; i<len; i++) {
    sum += arguments[i];
  }
  return sum;
}
console.log(add("Hello", 1, 2, 3, 4));

// 2. ES2015 - Using rest parameters (...)
function addNew(...num) {
  var sum = 0;
  for (let i=0; i<num.length; i++) {
    sum += num[i];
  }
  return sum;
}

console.log(addNew(1, 2, 3, 4));

// 3. ES2015 - Another example of rest parameters (...)
function sum(name, num1, num2, ...rest) {
  var sum = 0;
  console.log("Name = " + name);
  sum = num1 + num2;
  for (let i=0; i<rest.length; i++) {
    sum += rest[i];
  }
  return sum;
}

console.log(sum("Hello", 1, 2, 3, 4, 5));
