// 1. ES5 - Array iteration
var seasons = ['Summer', 'Spring', 'Autumn', 'Winter'];
console.log("1. Demo of ES5 array iteration");
for (var i = 0; i < seasons.length; i++) {
  console.log(seasons[i]);
}
//==============================================================================
// 2. ES6 - Array iteration - of
console.log("2. Demo of ES6 arrays - of");
for (let season of seasons) {
  console.log(season);
}
//==============================================================================
// 3. ES6 - Array iteration - in
console.log("3. Demo of ES6 arrays - in");
for (let index in seasons) {
  console.log(index);
}
//==============================================================================
// 4. ES5 way of converting Array-like objects to Array.
console.log("4. Demo of converting Array-like objects to Array - ES5");
function display() {
  console.log(arguments);
  var array1 = Array.prototype.slice.call(arguments);  // ES5
  console.log(array1);
}
display(1, 2, 3);
//==============================================================================
// 5. ES6 way - Array.from
console.log("5. Demo of converting Array-like objects to Array - ES6");
function displayNumbers() {
  console.log(arguments);
  var array2 = Array.from(arguments);                  // ES6
  console.log(array2);
}
displayNumbers(4, 5, 6);
//==============================================================================
// 6. ES6 way - Array.from can be used for strings also
console.log("6. Demo of using Array.from for strings");
console.log(Array.from("strings also"));
//==============================================================================
// 7. ES6 - Array.find and Array.findIndex
console.log("6. Demo of Array.find and Array.findIndex");
const array3 = [25, 29, 37, 45, 63];
console.log(array3.find(n => n > 30));
console.log(array3.findIndex(n => n > 30));
//==============================================================================
