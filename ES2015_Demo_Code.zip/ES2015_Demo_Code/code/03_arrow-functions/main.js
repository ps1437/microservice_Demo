// 1. SINGLE ARGUMENT
// ES5 - Normal function
var square1 = function (x) {
  return x * x;
}
console.log(square1(5));

// ES2015 - Arrow function
var square2 = x => x * x;
console.log(square2(6));
//==============================================================================
// 2. MULTIPLE ARGUMENTS
// ES5 - Normal function
var addNumber1 = function (num1, num2) {
  return num1 + num2;
}
console.log(addNumber1(1, 2));

// ES2015 - Arrow function
var addNumber2 = (num1, num2) => num1 + num2;
console.log(addNumber2(3, 4));
//==============================================================================
// 3. Arrow function - TRADITIONAL FUNCTION BODY - braces { } and explicit return value
var addNumber3 = (num1, num2) => {
  return num1 + num2;
}
console.log(addNumber2(5, 6));
//==============================================================================
// 4. NO ARGUMENTS
var getCountry1 = function() {
    return "India";
};
console.log(getCountry1());

var getCountry2 = () => "India";
console.log(getCountry2());
//==============================================================================
// 5. FUNCTION THAT DOES NOTHING
// ES5 - Normal function
var functionEmpty1 = function() {};

// ES2015 - Arrow function - Include curly braces {}
var functionEmpty2 = () => {};
//==============================================================================
// 6. RETURNING AN OBJECT LITERAL
// ES5 - Normal function
var getUserInfo1 = function(id) {
  return {
        id: id,
        name: "Ram"
    };
};

// ES2015 - Arrow function - Wrap object literal in parantheses ( )
var getUserInfo2 = id => ({ id: id, name: "Ram" })
//==============================================================================
// 7. this in normal function - ES5
var Message = {
  message: "Hello",
  handleDisplay: function(displayType, handler) {
    handler(displayType);
  },
  display: function() {
    var self = this;
    this.handleDisplay(true, function(displayType) {
      console.log(displayType ? self.message.toUpperCase() : self.message.toLowerCase());
    })
  }
}
Message.display();
//==============================================================================
// 8. this in arrow function - ES2015
var Message = {
  message: "Hello",
  handleDisplay: function(displayType, handler) {
    handler(displayType);
  },
  display: function() {
    this.handleDisplay(false,
      displayType => console.log(displayType ? this.message.toUpperCase() : this.message.toLowerCase())) 
  }
}
Message.display();
//==============================================================================
