// 1. startsWith
var str = 'JavaScript is the most popular technology';
console.log("==> 1) startsWith");
console.log(str.startsWith('JavaScript'));          // true
console.log(str.startsWith('most popular'));        // false
console.log(str.startsWith('most popular', 18));    // true
//==============================================================================
// 2. endsWith
console.log("==> 2) endsWith");
console.log(str.endsWith('technology'));            // true
console.log(str.endsWith('most popular'));          // false
console.log(str.endsWith('most popular', 30));      // true
//==============================================================================
// 3. includes
console.log("==> 3) includes");                     // CASE SENSITIVE
console.log(str.includes('JavaScript'));            // true
console.log(str.includes('technology'));            // true
console.log(str.includes('Python'));                // false
console.log(str.includes('JAVASCRIPT'));            // false
//==============================================================================
// 4. repeat
console.log("==> 4) repeat");
console.log("=".repeat(50));
//==============================================================================
