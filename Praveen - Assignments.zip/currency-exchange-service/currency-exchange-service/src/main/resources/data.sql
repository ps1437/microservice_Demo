insert into exchange_value(id,FROM_CURRENCY,TO_CURRENCY,CONVERSION_MUL,APPL_PORT)
values(10001,'USD','INR',65,0);
insert into exchange_value(id,FROM_CURRENCY,TO_CURRENCY,CONVERSION_MUL,APPL_PORT)
values(10002,'EUR','INR',75,0);
insert into exchange_value(id,FROM_CURRENCY,TO_CURRENCY,CONVERSION_MUL,APPL_PORT)
values(10003,'AUD','INR',25,0);