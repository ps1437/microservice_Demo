let empid = 3;

myMap1 = new Map(); // id -> name
myMap1.set(1, "Ram");
myMap1.set(2, "Raj");
myMap1.set(3, "Vinay");

myMap2 = new Map();  // name -> city
myMap2.set("Ram", "Chennai");
myMap2.set("Raj", "Pune");
myMap2.set("Vinay", "Bangalore");

myMap3 = new Map(); // city -> state
myMap3.set("Chennai", "Tamil Nadu");
myMap3.set("Pune", "Maharashtra");
myMap3.set("Bangalore", "Karnataka");

// Asynchronous way of calling functions sequentially using callback
function getEmployeeName(id, cb1) {
  setTimeout(function() {
    if (id <= 3)
      cb1(null, myMap1.get(id));
    else
      cb1("Invalid employee id");
  }, 1000);
}

function getEmployeeCity(name, cb2) {
  setTimeout(function() {
    cb2(null, myMap2.get(name));
  }, 1000);
}

function getEmployeeState(city, cb3) {
  setTimeout(function() {
    cb3(null, myMap3.get(city));
  }, 1000);
}

getEmployeeName(empid, function(err1, name) {
  if (err1 != null) {
    console.log(err1);
  }
  else {
      getEmployeeCity(name, function(err2, city) {
        if (err2 != null) {
        }
        else {
          getEmployeeState(city, function(err3, state) {
            if (err3 != null) {
            }
            else {
              console.log(state);
            }
          })
        }
      })
    }
});
console.log("Getting the state of the empid = " + empid);
